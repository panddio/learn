/*
 *  Copyright (C) 2017, Wang Qiuwei <qiuwei.wang@ingenic.com, panddio@163.com>
 *
 *  Ingenic Linux plarform SDK project
 *
 * This software may be distributed, used, and modified under the terms of
 * BSD license:

 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:

 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name(s) of the above-listed copyright holder(s) nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 *  You should have received a copy of the BSD License along with this program.
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <fcntl.h>
#include <dirent.h>
#include <netdb.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/types.h>

#include "os_unix.h"
#include "wpa_ctrl.h"
#include "wpa_cli.h"


/**
 * Functions
 */
int wpa_ctrl_request(struct wpa_ctrl *ctrl, const char *cmd, size_t cmd_len,
        char *reply, size_t *reply_len,
        void (msg_cb)(char *msg, size_t len))
{
    struct timeval tv;
    struct timeval started_at;
    int ret;
    fd_set rfds;
    const char *_cmd = cmd;
    size_t _cmd_len = cmd_len;

    errno = 0;
    started_at.tv_sec = 0;
    started_at.tv_usec = 0;

retry_send:
    if (send(ctrl->sockfd, _cmd, _cmd_len, 0) < 0) {
        if (errno == EAGAIN ||
            errno == EBUSY ||
            errno == EWOULDBLOCK) {
            if (started_at.tv_sec == 0)
                os_get_reltime(&started_at);
            else {
                struct timeval n;
                os_get_reltime(&n);
                /**
                 * Try for a few seconds
                 */
                if (os_reltime_expired(&n, &started_at, 5)) {
                    return -1;
                }
            }
            os_sleep(1, 0);
            goto retry_send;
        }
    }

    for(;;) {
        tv.tv_sec = 10;
        tv.tv_usec = 0;
        FD_ZERO(&rfds);
        FD_SET(ctrl->sockfd, &rfds);

        ret = select(ctrl->sockfd + 1, &rfds, NULL, NULL, &tv);
        if (ret < 0 || errno == EINTR)
            continue;
        if (ret < 0)
            return ret;
        if (FD_ISSET(ctrl->sockfd, &rfds)) {
            ret = recv(ctrl->sockfd, reply, WPA_CLI_MAX_REPLY_LEN - 1, 0);
            if (ret < 0)
                return ret;
            if (ret >= WPA_CLI_MAX_REPLY_LEN)
                ret = WPA_CLI_MAX_REPLY_LEN - 1;

            reply[ret] = '\0';

            if (reply[0] == '<') {
                /**
                 * This is an unsolicated message from wpa_supplicant,
                 * not the reply to the request.
                 * Use msg_cb to report this to the caller.
                 */
                if (msg_cb) {
                    msg_cb(reply, ret);
                }
                continue;
            }

            /**
             *  Return lenght of the reply message
             */
            *reply_len = ret;
            break;
        } else {
            return -2;
        }
    }

    return 0;
}

static void wpa_cli_msg_cb(char *msg, size_t len)
{
    printf("%s\n%s\n", __FUNCTION__, msg);
}

int wpa_ctrl_command(struct wpa_ctrl *ctrl, char *cmd, char *reply, size_t *reply_len)
{
    int ret;

    if (ctrl == NULL) {
        printf("Not connected to wpa_supplicant, command dropped\n");
        return -1;
    }

    ret = wpa_ctrl_request(ctrl, cmd, strlen(cmd),reply, reply_len, wpa_cli_msg_cb);
    if (ret == 2) {
        printf("%s command timeout\n", cmd);
        return -2;
    } else if (ret < 0) {
        printf("'%s' command failed\n", cmd);
        return -1;
    }

#if WPA_CLI_PRINT_REPLY
    printf("%s\n", reply);
#endif

    return 0;
}

struct wpa_ctrl *wpa_ctrl_open(const char *ctrl_path)
{
    struct wpa_ctrl *ctrl;
    static int counter = 0;
    int ret;
    int tries = 0;
    int flags;

    if (ctrl_path == NULL)
        goto wpa_ctrl_open_err1;

    ctrl = os_zalloc(sizeof(struct wpa_ctrl));
    if (ctrl == NULL)
        goto wpa_ctrl_open_err1;

    ctrl->sockfd = socket(PF_UNIX, SOCK_DGRAM, 0);
    if (ctrl->sockfd < 0) {
        goto wpa_ctrl_open_err2;
    }

    ctrl->local.sun_family = AF_UNIX;
    counter++;

try_again:
    ret = snprintf(ctrl->local.sun_path,
            sizeof(ctrl->local.sun_path),
            CONFIG_CTRL_IFACE_CLIENT_DIR "/"
            CONFIG_CTRL_IFACE_CLIENT_PREFIX "%d-%d",
            (int)getpid(), counter);
    if (os_snprintf_fail(sizeof(ctrl->local.sun_path), ret)) {
        goto wpa_ctrl_open_err3;
    }
    tries++;

    if (bind(ctrl->sockfd, (struct sockaddr *)&ctrl->local,
            sizeof(ctrl->local)) < 0) {
        if (errno == EADDRINUSE && tries < 2) {
            unlink(ctrl->local.sun_path);
            goto try_again;
        }
        goto wpa_ctrl_open_err3;
    }

    ctrl->dest.sun_family = AF_UNIX;
    ret = os_strlcpy(ctrl->dest.sun_path, ctrl_path,
            sizeof(ctrl->dest.sun_path));
    if (ret >= sizeof(ctrl->dest.sun_path)) {
        goto wpa_ctrl_open_err4;
    }

    if (connect(ctrl->sockfd, (struct sockaddr *)&ctrl->dest,
                sizeof(ctrl->dest)) < 0) {
        goto wpa_ctrl_open_err4;
    }

    /**
     * Make socket non-blocking so that we don't hang forever if
     * target dies unexpectedly.
     */
    flags = fcntl(ctrl->sockfd, F_GETFL);
    if (flags >= 0) {
        flags |= O_NONBLOCK;
        if (fcntl(ctrl->sockfd, F_SETFL, flags) < 0) {
            perror("fcntl(ctrl->sockfd, O_NONBLOCK)");
        }
    }

    return ctrl;

wpa_ctrl_open_err4:
    unlink(ctrl->local.sun_path);
wpa_ctrl_open_err3:
    close(ctrl->sockfd);
wpa_ctrl_open_err2:
    free(ctrl);
wpa_ctrl_open_err1:
    return NULL;
}

void wpa_ctrl_close(struct wpa_ctrl *ctrl)
{
    if (ctrl == NULL)
        return;
    unlink(ctrl->local.sun_path);
    if (ctrl->sockfd >= 0)
        close(ctrl->sockfd);
    free(ctrl);
    ctrl = NULL;
}
