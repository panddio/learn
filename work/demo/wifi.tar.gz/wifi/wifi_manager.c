/*
 *  Copyright (C) 2017, Wang Qiuwei <qiuwei.wang@ingenic.com, panddio@163.com>
 *
 *  Ingenic Linux plarform SDK project
 *
 *  This program is free software; you can redistribute it and/or modify it
 *  under  the terms of the GNU General  Public License as published by the
 *  Free Software Foundation;  either version 2 of the License, or (at your
 *  option) any later version.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <fcntl.h>
#include <dirent.h>
#include <stdbool.h>
#include <pthread.h>
#include <netdb.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/types.h>

#include "os_unix.h"
#include "wpa_ctrl.h"
#include "wpa_cli.h"
#include "wifi_manager.h"


int wifi_connect_to_new_network(const char *ssid, const char *password, const char *ifname)
{
    char cmd[256] = {0};
    int retval;

    if (wpa_cli_cmd_request("disable_network 0") < 0)
        return -1;

    retval = snprintf(cmd, sizeof(cmd), "set_network 0 ssid \"%s\"", ssid);
    if (os_snprintf_fail(sizeof(cmd), retval))
        return -1;
    printf("cmd=%s\n", cmd);
    if (wpa_cli_cmd_request(cmd) < 0)
        return -1;

    retval = snprintf(cmd, sizeof(cmd), "set_network 0 psk \"%s\"", password);
    if (os_snprintf_fail(sizeof(cmd), retval))
        return -1;
    printf("cmd=%s\n", cmd);
    if (wpa_cli_cmd_request(cmd) < 0)
        return -1;

    if (wpa_cli_cmd_request("enable_network 0") < 0)
        return -1;

    retval = snprintf(cmd, sizeof(cmd), "udhcpc -i %s -q", ifname);
    if (os_snprintf_fail(sizeof(cmd), retval)) {
        return -2;
    }
    printf("cmd=%s\n", cmd);
    system(cmd);

    return wpa_cli_cmd_request("save_config");
}

static void wifi_manager_sighandler(int signo)
{
    if (signo == SIGINT) {
        printf("Recv SIGINT, process exit\n");
        wpa_cli_cleanup();
        exit(0);
    }
}

int main(int argc, char *argv[])
{
    char ifname[IFNAMSIZ];
    char cmd[4096];
    char *msg = NULL;
    char *pos, *end;
    size_t len = 0;


    signal(SIGINT, wifi_manager_sighandler);

    if (wpa_cli_get_default_ifname(ifname) < 0) {
        printf("Failed to get ifname\n");
        return -1;
    }
    printf("Default ifname: %s\n", ifname);

    if (wpa_cli_open_connection(ifname) < 0) {
        printf("Failed to open connection\n");
        return -1;
    }

    while(1) {
        bzero(cmd, sizeof(cmd));

        printf("\033[34m> \033[0m");
        fflush(stdout);
        fgets(cmd, sizeof(cmd), stdin);
        cmd[strlen(cmd) - 1] = '\0';

        if (strcmp("q", cmd) == 0 ||
            strcmp("quit", cmd) == 0) {
            break;
        } else if (strcmp("test", cmd) == 0) {
            wifi_connect_to_new_network("Jizhiyun", "szingenic", ifname);
            continue;
        }

        if (wpa_cli_cmd_request(cmd) == 0) {
            /**
             * CMD request successful
             */
            wpa_cli_get_relpy_msg(&msg, &len);
#if 0
            printf("--------------------------------\n");
            printf("Reply msg_len=%ld, msg:\n\n", len);
            printf("%s\n", msg);
            printf("--------------------------------\n");
#else
            printf("--------------------------------\n");
            printf("%s\n", msg);
            pos = strstr(msg, "wpa_state=");
            if (!pos)
                continue;
            end = strchr(pos, '\n');
            if (!end)
                continue;
            *end = '\0';
            pos = strchr(pos, '=');
            if (!pos)
                continue;
            pos++;
            printf("wpa_state='%s'\n", pos);
            printf("--------------------------------\n");
#endif
        }
    }

    wpa_cli_cleanup();
    return 0;
}
