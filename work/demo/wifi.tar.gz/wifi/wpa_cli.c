/*
 *  Copyright (C) 2017, Wang Qiuwei <qiuwei.wang@ingenic.com, panddio@163.com>
 *
 *  Ingenic Linux plarform SDK project
 *
 * This software may be distributed, used, and modified under the terms of
 * BSD license:

 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:

 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name(s) of the above-listed copyright holder(s) nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 *  You should have received a copy of the BSD License along with this program.
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <fcntl.h>
#include <dirent.h>
#include <netdb.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/types.h>

#include "os_unix.h"
#include "wpa_ctrl.h"
#include "wpa_cli.h"


static struct wpa_ctrl *ctrl_conn = NULL;
static char cmdbuf[WPA_CLI_MAX_CMD_LEN];
static char reply[WPA_CLI_MAX_REPLY_LEN];
static size_t reply_len = 0;


/**
 * Functions
 */
static int wpa_cli_edit_cmd(char *cmd, char *argv[])
{
    int argc = 0;
    char *pos = cmd;

    for(;;) {
        while(*pos == ' ')
            pos++;
        if (*pos == '\0')
            break;

        argv[argc] = pos;
        argc++;
        if (argc == WPA_CLI_MAX_ARGS)
            break;
        if (*pos == '"') {
            char *pos2 = strrchr(pos, '"');
            if (pos2)
                pos = pos2 + 1;
        }

        while(*pos != '\0' && *pos != ' ')
            pos++;
        if (*pos == ' ')
            *pos++ = '\0';
    }

    return argc;
}

static int wpa_cli_make_cmd(char *buf, size_t buflen, const char *cmd,
            int argc, char *argv[])
{
    int i, ret;
    char *pos, *end;

    pos = buf;
    end = buf + buflen;

    ret = snprintf(pos, end - pos, "%s", cmd);
    if (os_snprintf_fail(end - pos, ret))
        goto make_cmd_fail;
    pos += ret;

    for (i = 0; i < argc; i++) {
        ret = snprintf(pos, end - pos, " %s", argv[i]);
        if (os_snprintf_fail(end - pos, ret))
            goto make_cmd_fail;
        pos += ret;
    }

    buf[buflen - 1] = '\0';
    return 0;

make_cmd_fail:
    printf("Too long command\n");
    return -1;
}

static int wpa_cli_cmd(struct wpa_ctrl *ctrl, const char *cmd, int min_args,
                int argc, char *argv[])
{
    char buf[4096];

    if (argc < min_args) {
        printf("Invalid %s command - at least %d argument%s"
               "requirst.\n", cmd, min_args,
               min_args > 1 ? "s are" : "is");
        return -1;
    }

    if (wpa_cli_make_cmd(buf, sizeof(buf), cmd, argc, argv) < 0)
        return -1;

    return wpa_ctrl_command(ctrl, buf, reply, &reply_len);
}

static int wpa_cli_cmd_ifname(struct wpa_ctrl *ctrl, int argc, char *argv[])
{
    return wpa_ctrl_command(ctrl, "IFNAME", reply, &reply_len);
}


static int wpa_cli_cmd_status(struct wpa_ctrl *ctrl, int argc, char *argv[])
{
    if (argc > 0 && strcmp(argv[0], "verbose") == 0)
        return wpa_ctrl_command(ctrl, "STATUS-VERBOSE", reply, &reply_len);
    if (argc > 0 && strcmp(argv[0], "wps") == 0)
        return wpa_ctrl_command(ctrl, "STATUS-WPS", reply, &reply_len);
    if (argc > 0 && strcmp(argv[0], "driver") == 0)
        return wpa_ctrl_command(ctrl, "STATUS-DRIVER", reply, &reply_len);

    return wpa_ctrl_command(ctrl, "STATUS", reply, &reply_len);
}


static int wpa_cli_cmd_ping(struct wpa_ctrl *ctrl, int argc, char *argv[])
{
    return wpa_ctrl_command(ctrl, "PING", reply, &reply_len);
}

static int wpa_cli_cmd_list_networks(struct wpa_ctrl *ctrl, int argc,
                     char *argv[])
{
    return wpa_ctrl_command(ctrl, "LIST_NETWORKS", reply, &reply_len);
}


static int wpa_cli_cmd_select_network(struct wpa_ctrl *ctrl, int argc,
                      char *argv[])
{
    return wpa_cli_cmd(ctrl, "SELECT_NETWORK", 1, argc, argv);
}


static int wpa_cli_cmd_enable_network(struct wpa_ctrl *ctrl, int argc,
                      char *argv[])
{
    return wpa_cli_cmd(ctrl, "ENABLE_NETWORK", 1, argc, argv);
}


static int wpa_cli_cmd_disable_network(struct wpa_ctrl *ctrl, int argc,
                       char *argv[])
{
    return wpa_cli_cmd(ctrl, "DISABLE_NETWORK", 1, argc, argv);
}


static int wpa_cli_cmd_add_network(struct wpa_ctrl *ctrl, int argc,
                   char *argv[])
{
    return wpa_ctrl_command(ctrl, "ADD_NETWORK", reply, &reply_len);
}


static int wpa_cli_cmd_remove_network(struct wpa_ctrl *ctrl, int argc,
                      char *argv[])
{
    return wpa_cli_cmd(ctrl, "REMOVE_NETWORK", 1, argc, argv);
}

static void wpa_cli_show_network_variables(void)
{
    printf("set_network variables:\n"
           "  ssid (network name, SSID)\n"
           "  psk (WPA passphrase or pre-shared key)\n"
           "  key_mgmt (key management protocol)\n"
           "  identity (EAP identity)\n"
           "  password (EAP password)\n"
           "  ...\n"
           "\n"
           "Note: Values are entered in the same format as the "
           "configuration file is using,\n"
           "i.e., strings values need to be inside double quotation "
           "marks.\n"
           "For example: set_network 1 ssid \"network name\"\n"
           "\n"
           "Please see wpa_supplicant.conf documentation for full list "
           "of\navailable variables.\n");
}


static int wpa_cli_cmd_set_network(struct wpa_ctrl *ctrl, int argc,
                   char *argv[])
{
    if (argc == 0) {
        wpa_cli_show_network_variables();
        return 0;
    }

    if (argc < 3) {
        printf("Invalid SET_NETWORK command: needs three arguments\n"
               "(network id, variable name, and value)\n");
        return -1;
    }

    return wpa_cli_cmd(ctrl, "SET_NETWORK", 3, argc, argv);
}


static int wpa_cli_cmd_get_network(struct wpa_ctrl *ctrl, int argc,
                   char *argv[])
{
    if (argc == 0) {
        wpa_cli_show_network_variables();
        return 0;
    }

    if (argc != 2) {
        printf("Invalid GET_NETWORK command: needs two arguments\n"
               "(network id and variable name)\n");
        return -1;
    }

    return wpa_cli_cmd(ctrl, "GET_NETWORK", 2, argc, argv);
}

static int wpa_cli_cmd_disconnect(struct wpa_ctrl *ctrl, int argc,
                  char *argv[])
{
    return wpa_ctrl_command(ctrl, "DISCONNECT", reply, &reply_len);
}

static int wpa_cli_cmd_reconnect(struct wpa_ctrl *ctrl, int argc,
                  char *argv[])
{
    return wpa_ctrl_command(ctrl, "RECONNECT", reply, &reply_len);
}

static int wpa_cli_cmd_save_config(struct wpa_ctrl *ctrl, int argc,
                   char *argv[])
{
    return wpa_ctrl_command(ctrl, "SAVE_CONFIG", reply, &reply_len);
}

static int wpa_cli_cmd_reconfigure(struct wpa_ctrl *ctrl, int argc,
                   char *argv[])
{
    return wpa_ctrl_command(ctrl, "RECONFIGURE", reply, &reply_len);
}

static int wpa_cli_cmd_scan(struct wpa_ctrl *ctrl, int argc, char *argv[])
{
    return wpa_cli_cmd(ctrl, "SCAN", 0, argc, argv);
}

static int wpa_cli_cmd_scan_results(struct wpa_ctrl *ctrl, int argc,
                    char *argv[])
{
    return wpa_ctrl_command(ctrl, "SCAN_RESULTS", reply, &reply_len);
}

static int wpa_cli_cmd_abort_scan(struct wpa_ctrl *ctrl, int argc,
                  char *argv[])
{
    return wpa_ctrl_command(ctrl, "ABORT_SCAN", reply, &reply_len);
}

static int wpa_cli_cmd_scan_interval(struct wpa_ctrl *ctrl, int argc,
                     char *argv[])
{
    return wpa_cli_cmd(ctrl, "SCAN_INTERVAL", 1, argc, argv);
}

static int wpa_cli_cmd_password(struct wpa_ctrl *ctrl, int argc, char *argv[])
{
    char cmd[256], *pos, *end;
    int i, ret;

    if (argc < 2) {
        printf("Invalid PASSWORD command: needs two arguments "
               "(network id and password)\n");
        return -1;
    }

    end = cmd + sizeof(cmd);
    pos = cmd;
    ret = snprintf(pos, end - pos, WPA_CTRL_RSP "PASSWORD-%s:%s",
              argv[0], argv[1]);
    if (os_snprintf_fail(end - pos, ret)) {
        printf("Too long PASSWORD command.\n");
        return -1;
    }
    pos += ret;
    for (i = 2; i < argc; i++) {
        ret = snprintf(pos, end - pos, " %s", argv[i]);
        if (os_snprintf_fail(end - pos, ret)) {
            printf("Too long PASSWORD command.\n");
            return -1;
        }
        pos += ret;
    }

    return wpa_ctrl_command(ctrl, cmd, reply, &reply_len);
}


static int wpa_cli_cmd_new_password(struct wpa_ctrl *ctrl, int argc,
                    char *argv[])
{
    char cmd[256], *pos, *end;
    int i, ret;

    if (argc < 2) {
        printf("Invalid NEW_PASSWORD command: needs two arguments "
               "(network id and password)\n");
        return -1;
    }

    end = cmd + sizeof(cmd);
    pos = cmd;
    ret = snprintf(pos, end - pos, WPA_CTRL_RSP "NEW_PASSWORD-%s:%s",
              argv[0], argv[1]);
    if (os_snprintf_fail(end - pos, ret)) {
        printf("Too long NEW_PASSWORD command.\n");
        return -1;
    }
    pos += ret;
    for (i = 2; i < argc; i++) {
        ret = snprintf(pos, end - pos, " %s", argv[i]);
        if (os_snprintf_fail(end - pos, ret)) {
            printf("Too long NEW_PASSWORD command.\n");
            return -1;
        }
        pos += ret;
    }

    return wpa_ctrl_command(ctrl, cmd, reply, &reply_len);
}

static int wpa_cli_cmd_terminate(struct wpa_ctrl *ctrl, int argc,
                 char *argv[])
{
    return wpa_ctrl_command(ctrl, "TERMINATE", reply, &reply_len);
}

static int wpa_cli_cmd_reassociate(struct wpa_ctrl *ctrl, int argc,
                   char *argv[])
{
    return wpa_ctrl_command(ctrl, "REASSOCIATE", reply, &reply_len);
}


static int wpa_cli_cmd_reattach(struct wpa_ctrl *ctrl, int argc, char *argv[])
{
    return wpa_ctrl_command(ctrl, "REATTACH", reply, &reply_len);
}

static int wpa_cli_cmd_dump(struct wpa_ctrl *ctrl, int argc, char *argv[])
{
    return wpa_ctrl_command(ctrl, "DUMP", reply, &reply_len);
}

static int wpa_cli_cmd_signal_poll(struct wpa_ctrl *ctrl, int argc,
                   char *argv[])
{
    return wpa_ctrl_command(ctrl, "SIGNAL_POLL", reply, &reply_len);
}

static int wpa_cli_cmd_help(struct wpa_ctrl *ctrl, int argc, char *argv[])
{
    wpa_cli_print_help(argc > 0 ? argv[0] : NULL);
    return 0;
}

enum wpa_cli_cmd_flags {
    cli_cmd_flag_none = 0x00,
    cli_cmd_flag_sensitive = 0x01
};

struct wpa_cli_cmd {
    const char *cmd;
    int (*handler)(struct wpa_ctrl *ctrl, int argc, char *argv[]);
    char **(*completion)(const char *str, int pos);
    enum wpa_cli_cmd_flags flags;
    const char *usage;
};

const struct wpa_cli_cmd wpa_cli_commands[] = {
    { "status", wpa_cli_cmd_status, NULL,
      cli_cmd_flag_none,
      "[verbose] = get current WPA/EAPOL/EAP status" },
    { "ifname", wpa_cli_cmd_ifname, NULL,
      cli_cmd_flag_none,
      "= get current interface name" },
    { "ping", wpa_cli_cmd_ping, NULL,
      cli_cmd_flag_none,
      "= pings wpa_supplicant" },
    { "list_networks", wpa_cli_cmd_list_networks, NULL,
      cli_cmd_flag_none,
      "= list configured networks" },
    { "select_network", wpa_cli_cmd_select_network, NULL,
      cli_cmd_flag_none,
      "<network id> = select a network (disable others)" },
    { "enable_network", wpa_cli_cmd_enable_network, NULL,
      cli_cmd_flag_none,
      "<network id> = enable a network" },
    { "disable_network", wpa_cli_cmd_disable_network, NULL,
      cli_cmd_flag_none,
      "<network id> = disable a network" },
    { "add_network", wpa_cli_cmd_add_network, NULL,
      cli_cmd_flag_none,
      "= add a network" },
    { "remove_network", wpa_cli_cmd_remove_network, NULL,
      cli_cmd_flag_none,
      "<network id> = remove a network" },
    { "set_network", wpa_cli_cmd_set_network, NULL,
      cli_cmd_flag_sensitive,
      "<network id> <variable> <value> = set network variables (shows\n"
      "  list of variables when run without arguments)" },
    { "get_network", wpa_cli_cmd_get_network, NULL,
      cli_cmd_flag_none,
      "<network id> <variable> = get network variables" },
    { "disconnect", wpa_cli_cmd_disconnect, NULL,
      cli_cmd_flag_none,
      "= disconnect and wait for reassociate/reconnect command before connecting" },
    { "reconnect", wpa_cli_cmd_reconnect, NULL,
      cli_cmd_flag_none,
      "= like reassociate, but only takes effect if already disconnected" },
    { "save_config", wpa_cli_cmd_save_config, NULL,
      cli_cmd_flag_none,
      "= save the current configuration" },
    { "reconfigure", wpa_cli_cmd_reconfigure, NULL,
      cli_cmd_flag_none,
      "= force wpa_supplicant to re-read its configuration file" },
    { "scan", wpa_cli_cmd_scan, NULL,
      cli_cmd_flag_none,
      "= request new BSS scan" },
    { "scan_results", wpa_cli_cmd_scan_results, NULL,
      cli_cmd_flag_none,
      "= get latest scan results" },
    { "abort_scan", wpa_cli_cmd_abort_scan, NULL,
      cli_cmd_flag_none,
      "= request ongoing scan to be aborted" },
    { "scan_interval", wpa_cli_cmd_scan_interval, NULL,
      cli_cmd_flag_none,
      "<value> = set scan_interval parameter (in seconds)" },
    { "password", wpa_cli_cmd_password, NULL,
      cli_cmd_flag_sensitive,
      "<network id> <password> = configure password for an SSID" },
    { "new_password", wpa_cli_cmd_new_password, NULL,
      cli_cmd_flag_sensitive,
      "<network id> <password> = change password for an SSID" },
    { "terminate", wpa_cli_cmd_terminate, NULL,
      cli_cmd_flag_none,
      "= terminate wpa_supplicant" },
    { "reassociate", wpa_cli_cmd_reassociate, NULL,
      cli_cmd_flag_none,
      "= force reassociation" },
    { "reattach", wpa_cli_cmd_reattach, NULL,
      cli_cmd_flag_none,
      "= force reassociation back to the same BSS" },
    { "dump", wpa_cli_cmd_dump, NULL,
      cli_cmd_flag_none,
      "= dump config variables" },
    { "signal_poll", wpa_cli_cmd_signal_poll, NULL,
      cli_cmd_flag_none,
      "= get signal parameters" },
    { "help", wpa_cli_cmd_help, NULL,
      cli_cmd_flag_none,
      "[command] = show usage help" },
    { NULL, NULL , NULL, cli_cmd_flag_none, NULL}
};

void wpa_cli_print_help(const char *cmd)
{
    char c;
    int n, m;

    printf("commands:\n");
    for (n = 0; wpa_cli_commands[n].cmd; n++) {
        if (cmd == NULL ||
            strncmp(wpa_cli_commands[n].cmd, cmd, strlen(cmd)) == 0) {
            printf("  %s ", wpa_cli_commands[n].cmd);
            for (m = 0; (c = wpa_cli_commands[n].usage[m]); m++) {
                printf("%c", c);
                if (c == '\n')
                    printf("  ");
            }
            printf("\n");
        }
    }
}

int wpa_cli_get_default_ifname(char *ifname)
{
    struct dirent *dent;
    DIR *dir = opendir(CONFIG_CTRL_IFACE_DIR);

    if (!dir)
        return -1;

    while ((dent = readdir(dir))) {
        if (strcmp(dent->d_name, ".") == 0 ||
            strcmp(dent->d_name, "..") == 0)
            continue;
        memcpy(ifname, dent->d_name, sizeof(dent->d_name));
        break;
    }

    closedir(dir);
    return 0;
}

int wpa_cli_open_connection(const char *ifname)
{
    char *cfile = NULL;
    int flen, ret;

    if (ifname == NULL)
        return -1;

    flen = strlen(CONFIG_CTRL_IFACE_DIR) + strlen(ifname) + 2;
    cfile = os_zalloc(flen);
    if (cfile == NULL)
        return -2;

    ret = snprintf(cfile, flen, "%s/%s", CONFIG_CTRL_IFACE_DIR, ifname);
    if (os_snprintf_fail(flen, ret)) {
        free(cfile);
        return -3;
    }

    ctrl_conn = wpa_ctrl_open(cfile);
    if (ctrl_conn == NULL) {
        free(cfile);
        return -4;
    }

    free(cfile);
    return 0;
}

static int wpa_cli_request(struct wpa_ctrl *ctrl, int argc, char *argv[])
{
    const struct wpa_cli_cmd *cmd, *match = NULL;
    int count;
    int ret;

    if (argc == 0)
        return -1;

    count = 0;
    cmd = wpa_cli_commands;
    while (cmd->cmd) {
        if (strncasecmp(cmd->cmd, argv[0], strlen(argv[0])) == 0) {
            match = cmd;
            if (strcasecmp(cmd->cmd, argv[0]) == 0) {
                count = 1;
                break;
            }
            count++;
        }
        cmd++;
    }

    if (count > 1) {
        printf("Ambiguous command '%s'\n", argv[0]);
        return 1;
    } else if (count == 0) {
        printf("Unknown command '%s'\n", argv[0]);
        return 1;
    } else {
        reply[0] = '\0';
        reply_len = 0;
        ret = match->handler(ctrl, argc - 1, &argv[1]);
    }

    return ret;
}

int wpa_cli_cmd_request(char *cmd)
{
    char *argv[WPA_CLI_MAX_ARGS];
    int argc;

    strcpy(cmdbuf, cmd);
    argc = wpa_cli_edit_cmd(cmdbuf, argv);
    if (argc) {
        return wpa_cli_request(ctrl_conn, argc, argv);
    }

    return -1;
}

void wpa_cli_get_relpy_msg(char **msg, size_t *len)
{
    if (msg != NULL)
        *msg = reply;
    if (len != NULL)
        *len = reply_len;
}

void wpa_cli_cleanup(void)
{
    wpa_ctrl_close(ctrl_conn);
}
