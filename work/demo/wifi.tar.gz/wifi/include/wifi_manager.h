/*************************************************************************
	> Filename: wifi_manager.h
	>   Author: Wang Qiuwei
	>    Email: qiuwei.wang@ingenic.com / panddio@163.com
	> Datatime: Wed 08 Nov 2017 06:20:30 PM CST
 ************************************************************************/

#ifndef _WIFI_MANAGER_H
#define _WIFI_MANAGER_H


#endif /* _WIFI_MANAGER_H */
