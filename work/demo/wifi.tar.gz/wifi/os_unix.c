/*
 *  Copyright (C) 2017, Wang Qiuwei <qiuwei.wang@ingenic.com, panddio@163.com>
 *
 *  Ingenic Linux plarform SDK project
 *
 * This software may be distributed, used, and modified under the terms of
 * BSD license:

 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:

 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name(s) of the above-listed copyright holder(s) nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 *  You should have received a copy of the BSD License along with this program.
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <fcntl.h>


/**
 * Functions
 */
void *os_zalloc(size_t size)
{
    return calloc(1, size);
}

void os_sleep(long sec, long usec)
{
    if (sec)
        sleep(sec);
    if (usec)
        usleep(usec);
}

int os_strlcpy(char *dest, const char *src, int size)
{
    const char *s = src;
    int left = size;

    if (left) {
        while(--left != 0) {
            if ((*dest++ = *s++) == 0)
                break;
        }
    }

    if (left == 0) {
        if (size != 0)
            *dest = '\0';
        while(*s++);
    }

    return s - src -1;
}

int os_get_reltime(struct timeval *t)
{
    struct timespec ts;
    int ret;

    ret = clock_gettime(CLOCK_REALTIME, &ts);
    if (ret == 0) {
        t->tv_sec = ts.tv_sec;
        t->tv_usec =  ts.tv_nsec / 1000;
        return 0;
    }

    return -1;
}
