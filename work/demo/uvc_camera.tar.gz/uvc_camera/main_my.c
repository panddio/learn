/*************************************************************************
    > Filename: main_my.c
    >   Author: Wang Qiuwei
    >    Email: qiuwei.wang@ingenic.com / panddio@163.com
    > Datatime: Mon 04 Dec 2017 04:57:28 PM CST
 ************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <assert.h>
#include <getopt.h>
#include <linux/fb.h>
#include <sys/mman.h>
#include <sys/ioctl.h>

#include <capture.h>
#include <decoder.h>
#include <rgb2bmp.h>
#include <decoder_mjpeg.h>
#include <decoder_yuv422.h>

#define CAM_DEVICE      "/dev/video0"
#define CAM_WIDTH       320
#define CAM_HEIGHT      240


static Decoder *decoder = NULL;
static unsigned int cnt = 0;
static unsigned char *rgb_buf = NULL;

static const char short_options[] = "d:f:hr:x:y:";
static const struct option long_options[] = {
    { "device",     1,      NULL,           'd' },
    { "format",     1,      NULL,           'f' },
    { "help",       0,      NULL,           'h' },
    { "rates",      1,      NULL,           'r' },
    { "width",      1,      NULL,           'x' },
    { "height",     1,      NULL,           'y' },
    { 0, 0, 0, 0 }
};

/*
 * Functions
 */
static void usage(FILE *fp, int argc, char *argv[])
{
    fprintf(fp,
             "\nUsage: %s [options]\n"
             "Options:\n"
             "-d | --device        Video device name [/dev/video]\n"
             "-f | --format        Pixel format\n"
             "-h | --help          Print this message\n"
             "-r | --rates         Frame rates\n"
             "-x | --width         Capture width\n"
             "-y | --height        Capture height\n"
             "\n", argv[0]);
}

int rgb2bmp(char *filename, unsigned int width, unsigned int height,\
        int iBitCount, unsigned char *rgbbuf)
{
    unsigned char *dstbuf;
    unsigned int i, j;
    unsigned long linesize, rgbsize;

    printf("sizeof(BITMAPFILEHEADER) = 0x%02x\n", (unsigned int)sizeof(BITMAPFILEHEADER));
    printf("sizeof(BITMAPINFOHEADER) = 0x%02x\n", (unsigned int)sizeof(BITMAPINFOHEADER));

    if(iBitCount == 24) {
        FILE *fp;
        long ret;
        BITMAPFILEHEADER bmpHeader;
        BITMAPINFO bmpInfo;

        if((fp = fopen(filename, "wb")) == NULL) {
            printf("Can not create BMP file: %s\n", filename);
            return -1;
        }

        rgbsize = width * height * 3;

        bmpHeader.bfType = (WORD)(('M' << 8) | 'B');
        bmpHeader.bfSize = rgbsize + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
        bmpHeader.bfReserved1 = 0;
        bmpHeader.bfReserved2 = 0;
        bmpHeader.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

        bmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bmpInfo.bmiHeader.biWidth = width;
        bmpInfo.bmiHeader.biHeight = height;
        bmpInfo.bmiHeader.biPlanes = 1;
        bmpInfo.bmiHeader.biBitCount = iBitCount;
        bmpInfo.bmiHeader.biCompression = 0;
        bmpInfo.bmiHeader.biSizeImage = rgbsize;
        bmpInfo.bmiHeader.biXPelsPerMeter = 0;
        bmpInfo.bmiHeader.biYPelsPerMeter = 0;
        bmpInfo.bmiHeader.biClrUsed = 0;
        bmpInfo.bmiHeader.biClrImportant = 0;

        if((ret = fwrite(&bmpHeader, 1, sizeof(BITMAPFILEHEADER), fp))
                != sizeof(BITMAPFILEHEADER))
            printf("write BMP file header failed: ret=%ld\n", ret);

        if((ret = fwrite(&(bmpInfo.bmiHeader), 1, sizeof(BITMAPINFOHEADER), fp))
                != sizeof(BITMAPINFOHEADER))
            printf("write BMP file info failed: ret=%ld\n", ret);

        /* convert rgbbuf */
        dstbuf = (unsigned char *)malloc(rgbsize);
        if(!dstbuf) {
            printf("malloc dstbuf failed !!\n");
            return -1;
        }

        linesize = width * 3; //line size
        for(i = 0, j = height -1; i < height - 1; i++, j--)
            memcpy((dstbuf + (linesize * j)), (rgbbuf + (linesize * i)), linesize);

        if((ret = fwrite(dstbuf, 1, rgbsize, fp)) != rgbsize)
            printf("write BMP file date failed: ret=%ld\n", ret);

        free(dstbuf);
        fclose(fp);
        return 0;
    } else {
        printf("%s: error iBitCount != 24\n", __FUNCTION__);
        return -1;
    }
}

void save_to_mjpg_file(void *buf_start, int buf_size)
{
    char filename[64]="";
    FILE *fp = NULL;
    unsigned long ret = 0;

    sprintf(filename, "test_%d.mjpg", cnt);

    if((fp = fopen(filename, "wb")) == NULL) {
        printf("Can not create MJPG file: %s\n", filename);
        exit(EXIT_FAILURE);
    }

    if (ret = fwrite(buf_start, 1, buf_size, fp) != buf_size) {
        printf("write MJPG file data failed: ret=%ld\n", ret);
        exit(EXIT_FAILURE);
    }
    fclose(fp);
}

static void save_image_to_file(void *ctx, void *buf_start, int buf_size)
{
    char filename[64]="";
    CameraDevice *camera = (CameraDevice *)ctx;

    if (camera->format == PIX_FMT_MJPEG)
        save_to_mjpg_file(buf_start, buf_size);

    decoder_decode(decoder, rgb_buf, buf_start, buf_size);

    sprintf(filename, "test_%d.bmp", cnt);
    rgb2bmp(filename, camera->width, camera->height, 24, rgb_buf);
}

int main(int argc, char *argv[])
{
    char *dev_name;
    int width;
    int height;
    int fps;
    int format;
    CameraDevice camera;

    dev_name = CAM_DEVICE;
    width = CAM_WIDTH;
    height = CAM_HEIGHT;
    fps = 0;
    format = PIX_FMT_YUYV;
    decoder = decoder_yuv422_create();

    while(1) {
        int oc;

        oc = getopt_long(argc, argv, \
                         short_options, long_options, \
                         NULL);
        if(-1 == oc)
            break;

        switch(oc) {
        case 0:
            break;

        case 'd':
            dev_name = optarg;
            break;

        case 'f':
            if (strcmp("mjpg", optarg) == 0) {
                decoder_destroy(decoder);
                format = PIX_FMT_MJPEG;
                decoder = decoder_mjpeg_create();
            }
            break;

        case 'h':
            usage(stdout, argc, argv);
            exit(EXIT_SUCCESS);
            break;

        case 'r':
            fps = atoi(optarg);
            break;

        case 'x':
            width = atoi(optarg);
            break;

        case 'y':
            height = atoi(optarg);
            break;

        default:
            usage(stderr, argc, argv);
            exit(EXIT_FAILURE);
            break;
        }
    }

    /* camera setting */
    camera_init(&camera, dev_name, width, height, fps, format);
    camera_open_set(&camera);

    rgb_buf = (unsigned char *)malloc(width * height * 3);
    if (!rgb_buf) {
        printf("Failed to alloc memcpy for rgb buffer\n");
        goto main_exit;
    }

    for (cnt = 0; cnt < 6; cnt++)
    {
        camera_read_frame(&camera, save_image_to_file, (void *)&camera);
    }

main_exit:
    free(rgb_buf);
    camera_close(&camera);
    decoder_destroy(decoder);
    return 0;
}
